#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <string>
#include <chrono>
#include <algorithm>
#include <iomanip>
#include <queue>
#include "CustomHashTable.h"

using namespace std;


void processLogFile(const string& filename, CustomHashTable& customHashTable, unordered_map<string, int>& stlHashMap) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Unable to open the file " << filename << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    while (getline(file, line)) {
        size_t startPos = line.find("\"GET ") + 5;
        size_t endPos = line.find(" HTTP/1.0");

        if (startPos != std::string::npos && endPos != std::string::npos) {
            string filename = line.substr(startPos, endPos - startPos);
            customHashTable.insert(filename);
            stlHashMap[filename]++;
        }
    }

    file.close();
}




vector<pair<string, int>> findTopPages(const unordered_map<string, int>& pageMap) {
    priority_queue<pair<int, string>> maxHeap;
    for (const auto& entry : pageMap) {
        maxHeap.push({entry.second, entry.first});
    }

    vector<pair<string, int>> topPages;
    while (!maxHeap.empty() && topPages.size() < 10) {
        auto topElement = maxHeap.top();
        topPages.push_back({topElement.second, topElement.first});
        maxHeap.pop();
    }


    return topPages;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <log_file>" << endl;
        return 1;
    }

    string filename = argv[1];
    cout << "Attempting to open file: " << filename << endl;

    auto startFileReading = chrono::high_resolution_clock::now();
    CustomHashTable customHashTable;
    unordered_map<string, int> stlHashMap;

    processLogFile(filename, customHashTable, stlHashMap);

    auto endFileReading = chrono::high_resolution_clock::now();
    auto durationFileReading = chrono::duration_cast<chrono::nanoseconds>(endFileReading - startFileReading);
    cout << "File Reading Time: " << durationFileReading.count() << " nanoseconds" << endl;

    auto startCustomHashTable = chrono::high_resolution_clock::now();
    auto customTopPages = findTopPages(stlHashMap);
    auto endCustomHashTable = chrono::high_resolution_clock::now();
    auto durationCustomHashTable = chrono::duration_cast<chrono::nanoseconds>(endCustomHashTable - startCustomHashTable);
    cout << "Custom Hash Table Time: " << durationCustomHashTable.count() << " nanoseconds" << endl;

    auto startStdUnorderedMap = chrono::high_resolution_clock::now();
    auto stlTopPages = findTopPages(stlHashMap);
    auto endStdUnorderedMap = chrono::high_resolution_clock::now();
    auto durationStdUnorderedMap = chrono::duration_cast<chrono::nanoseconds>(endStdUnorderedMap - startStdUnorderedMap);
    cout << "unordered_map Time: " << durationStdUnorderedMap.count() << " nanoseconds" << endl;

    cout << "\nTop 10 most visited pages using custom hash table:\n";
    for (const auto& entry : customTopPages) {
        cout << setw(20) << entry.first << "  # of total visits: " << entry.second << endl;
    }

    cout << "\nTop 10 most visited pages using unordered_map:\n";
    for (const auto& entry : stlTopPages) {
        cout << setw(20) << entry.first << "  # of total visits: " << entry.second << endl;
    }

    return 0;
}
