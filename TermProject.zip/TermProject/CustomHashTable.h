


#ifndef TERMPROJECT_CUSTOMHASHTABLE_H
#define TERMPROJECT_CUSTOMHASHTABLE_H

using namespace std;
#include <string>


class CustomHashTable {
private:
    static const int tableSize = 1000;
    struct Node {
        string filename;
        int visits;
        Node* next;
        Node(const string& fname, int v) : filename(fname), visits(v), next(nullptr) {}
    };
    Node* table[tableSize];

public:
    CustomHashTable();

    ~CustomHashTable();

    void insert(const string& filename);

    int getVisits(const string& filename);

private:
    int hashFunction(const string& str);
};


#endif //TERMPROJECT_CUSTOMHASHTABLE_H
