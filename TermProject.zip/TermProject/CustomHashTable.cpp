

#include "CustomHashTable.h"

CustomHashTable::CustomHashTable() {
    for (int i = 0; i < tableSize; i++) {
        table[i] = nullptr;
    }
}

CustomHashTable::~CustomHashTable() {
    for (int i = 0; i < tableSize; i++) {
        Node* current = table[i];
        while (current != nullptr) {
            Node* next = current->next;
            delete current;
            current = next;
        }
    }
}

void CustomHashTable:: insert(const string& filename) {
    int index = hashFunction(filename);
    Node* newNode = new Node(filename, 1);
    newNode->next = table[index];
    table[index] = newNode;
}

int CustomHashTable::getVisits(const string& filename) {
    int index = hashFunction(filename);
    Node* current = table[index];
    while (current != nullptr) {
        if (current->filename == filename) {
            return current->visits;
        }
        current = current->next;
    }
    return 0;
}


int CustomHashTable::hashFunction(const string& str) {
    int hash = 0;
    for (char ch : str) {
        hash = (hash * 31 + ch) % tableSize;
    }
    return hash;
}